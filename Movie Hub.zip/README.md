# About

This project was created for the Introduction to WWW course at BUT.

<hr/>

# Installation

The project was built using Node.js v22.2.0 and Safari 18.0 (20619.1.15.11.1).

In the project directory, run the following commands:

```shell
npm i yarn -g
yarn install
yarn start
```

Then, head to [http://localhost:3000/](http://localhost:3000/)

<hr />

# Fonts

Fonts used made by Apple Inc. include:

- [SF Pro](https://developer.apple.com/fonts/)

<hr />

# Project Rights

All rights reserved. Copying and/or redistributing is not allowed.
